export { Slider } from './Slider';
