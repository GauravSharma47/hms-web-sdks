export { StyledPagination } from './StyledPagination';
