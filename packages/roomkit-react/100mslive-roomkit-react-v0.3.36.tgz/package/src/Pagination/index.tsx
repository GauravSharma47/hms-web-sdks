export { StyledPagination } from './StyledPagination';
