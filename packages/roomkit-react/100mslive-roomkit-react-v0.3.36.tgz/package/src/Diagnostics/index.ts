export { Diagnostics } from './Diagnostics';
