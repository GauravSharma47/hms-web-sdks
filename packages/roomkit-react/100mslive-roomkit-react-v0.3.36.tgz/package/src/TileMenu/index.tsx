export { StyledMenuTile } from './StyledMenuTile';
