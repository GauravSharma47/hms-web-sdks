export { StyledMenuTile } from './StyledMenuTile';
